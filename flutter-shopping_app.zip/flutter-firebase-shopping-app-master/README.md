# App Screens
<table> 
  
   <tr>
     <th>Home</th>
     <th>Favourite</th> 
   </tr>
    
   <tr>
     <td>
         <img src="https://user-images.githubusercontent.com/18363332/78084126-b6204900-73b7-11ea-9089-0a7af6c8ff88.png">
     </td>
     <td>
         <img src="https://user-images.githubusercontent.com/18363332/78084179-cd5f3680-73b7-11ea-9c51-d5156aee42f1.png">
     </td>
  
   <tr>
     <th>More</th>
     <th>MyProducts</th> 
   </tr>
   <tr>
     <td>
         <img src="https://user-images.githubusercontent.com/18363332/78084187-d0f2bd80-73b7-11ea-81ed-a96d0db75d5f.png">
     </td>
     <td>
         <img src="https://user-images.githubusercontent.com/18363332/78084217-e23bca00-73b7-11ea-9c78-9e0a0e2c1220.png">
     </td>
  </tr>
  
   <tr>
     <th>AddProduct</th>
     <th>AddingItemToCart</th> 
   </tr>
   <tr>
     <td>
         <img src="https://user-images.githubusercontent.com/18363332/78084225-e667e780-73b7-11ea-964f-6b4c0ea5e6d6.png">
     </td>
     <td>
         <img src="https://user-images.githubusercontent.com/18363332/78084149-bfa9b100-73b7-11ea-8756-ec4f01ad5d54.png">
     </td>
  </tr> 
    
   <tr>
     <th>Cart</th>
     <th>DeleteItemFromCart</th> 
  </tr>
   <tr>
     <td>
         <img src="https://user-images.githubusercontent.com/18363332/78084191-d4864480-73b7-11ea-831c-0c787fcd6086.png">
     </td>
     <td>
         <img src="https://user-images.githubusercontent.com/18363332/78084210-de0fac80-73b7-11ea-9f05-06cb8f0f5625.png">
     </td>
  </tr> 
     
     
    
</table>


# firebase_shop_app

A new Flutter application.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
